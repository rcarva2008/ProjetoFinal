/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author devmat
 */
public class Carros {
    int id;
    String Preco;
    String modelo;
    String Cor;
    String Placa;
    String descricao;
    String vendaAlugar;
    //String imagem; // Para armazenar a imagem em formato binário
    String caminhoImagem;
    byte[] imagem;
    
    
    public Carros() {
    }

    public Carros(String Preco, String modelo, String Cor, String Placa, String descricao, String Usuarionome, String vendaAlugar, byte[] imagem) {
        this.Preco = Preco;
        this.modelo = modelo;
        this.Cor = Cor;
        this.Placa = Placa;
        this.descricao = descricao;
        this.vendaAlugar = vendaAlugar;
        this.imagem = imagem;
    }

    public Carros(int id, String Preco, String modelo, String Cor, String Placa, String descricao, String Usuarionome, String vendaAlugar, byte[] imagem) {
        this.id = id;
        this.Preco = Preco;
        this.modelo = modelo;
        this.Cor = Cor;
        this.Placa = Placa;
        this.descricao = descricao;
        this.vendaAlugar = vendaAlugar;
        this.imagem = imagem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPreco() {
        return Preco;
    }

    public void setPreco(String Preco) {
        this.Preco = Preco;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return Cor;
    }

    public void setCor(String Cor) {
        this.Cor = Cor;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descrição) {
        this.descricao = descrição;
    } 
    public String getVendaAlugar() {
        return vendaAlugar;
    }

    public void setVendaAlugar(String vendaAlugar) {
        this.vendaAlugar = vendaAlugar;
    }

   /* public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }*/
    
     public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }
    
}