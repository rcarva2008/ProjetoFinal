/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lojaautomotiva;

import View.TelaCadastro;

/**
 *
 * @author devmat
 */
public class LojaAutomotiva {

    public static void main(String[] args) {
        TelaCadastro tela = new TelaCadastro();
        tela.setVisible(true);
    }
}
