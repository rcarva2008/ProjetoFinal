/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.cadastrcarroController;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import model.Carros;

/**
 *
 * @author devmat
 */
public class TelaCompra extends javax.swing.JFrame {

    /**
     * Creates new form TelaCompra
     */
    cadastrcarroController controller = new cadastrcarroController();
    public TelaCompra()  {
        initComponents();
     PesquisarProduto();
      adicionarCards(null);
      
    }
  
    
    
    public void PesquisarProduto(){
        campoPesquisa.getDocument().addDocumentListener(
                new DocumentListener(){     
                 @Override
                 public void insertUpdate(javax.swing.event.DocumentEvent e){
                     Pesquisar();
                 }// fim do insertUpdate
                 @Override
                  public void removeUpdate(javax.swing.event.DocumentEvent e){
                      Pesquisar();
                  }  //removeUpdate
                  @Override
                  public void changedUpdate(javax.swing.event.DocumentEvent e){
                      Pesquisar();
                  }// fim do changedUpdate
                    private void Pesquisar(){
                        adicionarCards(campoPesquisa.getText());  
                    } // fim do pesquisar()  
                 
                });// fim do metodo de captura   
    }// fim do PesquisarProduto
    
    
    
   private void gerarPDF(Carros carro) {
    try {
        // Cria o documento PDF
        com.itextpdf.text.Document document = new com.itextpdf.text.Document();

        
        String fileName = "Carro_" + carro.getModelo() + ".pdf";
        PdfWriter.getInstance(document, new FileOutputStream(fileName));

        // Abre o documento para escrita
        document.open();

        // Adiciona título ao PDF
        document.add(new Paragraph("Detalhes do Carro", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
        document.add(new Paragraph("\n"));

        // Adiciona título ao PDF (cabeçalho)
document.add(new Paragraph("COMPROVAÇÃO DE VENDA DE VEÍCULO", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20)));
document.add(new Paragraph("\n"));
document.add(new Paragraph("Documento Oficial de Transferência de Propriedade", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14)));
document.add(new Paragraph("\n"));

// Detalhes do carro
document.add(new Paragraph("Detalhes do Veículo:", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12)));
document.add(new Paragraph("Modelo: " + carro.getModelo()));
document.add(new Paragraph("Cor: " + carro.getCor()));
document.add(new Paragraph("Placa: " + carro.getPlaca()));
document.add(new Paragraph("Descrição: " + carro.getDescricao()));
document.add(new Paragraph("\n"));

// Detalhes de venda
document.add(new Paragraph("Informações de Venda:", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12)));
document.add(new Paragraph("Preço: " + carro.getPreco()));
document.add(new Paragraph("Status: " + (carro.getVendaAlugar().equals("Vender") ? "Vendido" : "Alugado")));
document.add(new Paragraph("\n"));

// Adiciona uma linha de assinatura (se necessário)
document.add(new Paragraph("________________________________________", FontFactory.getFont(FontFactory.HELVETICA, 12)));
document.add(new Paragraph("Assinatura do Vendedor", FontFactory.getFont(FontFactory.HELVETICA, 12)));
document.add(new Paragraph("\n"));
document.add(new Paragraph("________________________________________", FontFactory.getFont(FontFactory.HELVETICA, 12)));
document.add(new Paragraph("Assinatura do Comprador", FontFactory.getFont(FontFactory.HELVETICA, 12)));

// Adiciona uma linha de data
document.add(new Paragraph("\nData da Transação: ____________________", FontFactory.getFont(FontFactory.HELVETICA, 12)));

        // Fecha o documento
        document.close();

        // Tenta abrir o PDF após a geração
        File pdfFile = new File(fileName);
        if (pdfFile.exists()) {
            Desktop.getDesktop().open(pdfFile);
        } else {
            JOptionPane.showMessageDialog(null, "Arquivo PDF não encontrado.");
        }

        // Mensagem de sucesso
        JOptionPane.showMessageDialog(null, "PDF gerado com sucesso!");

    } catch (DocumentException | IOException e) {
        // Em caso de erro na criação do PDF
        JOptionPane.showMessageDialog(null, "Erro ao gerar o PDF: " + e.getMessage());
    }
}
    
    
  public void adicionarCards(String modelo) {
    
    List<Carros> listaCarros;
        if (modelo == null) { 
            listaCarros = controller.listarCarros();
        } else {
            listaCarros = controller.listarCarrosModelo(modelo);
        }

    // Criando um painel para os cards com GridLayout
    JPanel cardsPanel = new JPanel(new GridLayout(0, 2, 10, 10)); // 2 colunas, espaçamento entre os cards
    cardsPanel.setOpaque(false); // Deixa o painel transparente
    
     
    for (Carros carro : listaCarros ) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        card.setBackground(Color.WHITE);
        
        // Carregar a imagem do banco de dados
        JLabel imagemLabel = new JLabel();
        byte[] imagemBytes = carro.getImagem(); // Obtém a imagem em bytes
        if (imagemBytes != null) {
            ImageIcon imagemIcon = new ImageIcon(imagemBytes);
            Image img = imagemIcon.getImage().getScaledInstance(230, 80, Image.SCALE_SMOOTH);
            imagemLabel.setIcon(new ImageIcon(img));
        } else {
            imagemLabel.setText("Sem imagem");
        }
        card.add(imagemLabel, BorderLayout.NORTH);

        // Painel para os textos (modelo, marca e status)
        JPanel textoPanel = new JPanel();
        textoPanel.setLayout(new GridLayout(3, 1));
        textoPanel.setBackground(Color.WHITE);

        JLabel modeloLabel = new JLabel("Modelo: " + carro.getModelo());
        modeloLabel.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel marcaLabel = new JLabel("Cor: " + carro.getCor());
        marcaLabel.setFont(new Font("Arial", Font.PLAIN, 12));

        JLabel statusLabel = new JLabel(carro.getVendaAlugar().equals("Vender") ? "À venda" : "Para aluguel");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        statusLabel.setForeground(carro.getVendaAlugar().equals("Vender") ? Color.RED : Color.BLUE);
    
        textoPanel.add(modeloLabel);
        textoPanel.add(marcaLabel);
        textoPanel.add(statusLabel);

        card.add(textoPanel, BorderLayout.CENTER);

        // Criar o botão "Saiba Mais"
        JButton saibaMaisButton = new JButton("Saiba mais");
        saibaMaisButton.setFont(new Font("Arial", Font.BOLD, 12));
        saibaMaisButton.setBackground(Color.BLUE);
        saibaMaisButton.setForeground(Color.WHITE);


// Adicionando o botão de ação para mostrar os detalhes do carro


saibaMaisButton.addActionListener(e -> {   
    // Definindo o status de venda ou aluguel
    String vendaAlugar = carro.getVendaAlugar();
    String statusTexto = vendaAlugar.equals("Vender") ? "À venda" : "Para aluguel";
    String statusTexto1 = vendaAlugar.equals("Vender") ? "Obter" : "Obter";  // Adicionei o ponto e vírgula
    Color statusColor = vendaAlugar.equals("Vender") ? Color.RED : Color.BLUE;

   
      int escolha = JOptionPane.showOptionDialog(
    null,
    "<html><b>Modelo:</b> " + carro.getModelo() + "<br>" + 
    "<b>Preço:</b> " + carro.getPreco() + "<br>" + 
    "<b>Cor:</b> " + carro.getCor() + "<br>" + 
    "<b>Placa:</b> " + carro.getPlaca() + "<br>" + 
    "<b>Descrição:</b> " + carro.getDescricao() + "<br>" + 
    "<b>Disponível para:</b> " + statusTexto + "</html>",
    "Detalhes do Carro",
    JOptionPane.DEFAULT_OPTION,
    JOptionPane.PLAIN_MESSAGE,
    null,
    new Object[]{statusTexto1, "Não " + statusTexto1},
    statusTexto1
);

if (escolha == 0) { // Usuário clicou em "Sim"
    // Gerar o PDF
    gerarPDF(carro);
    
    // Exibir mensagem de sucesso
    JOptionPane.showMessageDialog(null, "PDF gerado com sucesso!");
} else {
    // Caso o usuário tenha escolhido "Não"
    JOptionPane.showMessageDialog(null, "Operação cancelada.");
}});


        card.add(saibaMaisButton, BorderLayout.SOUTH);

        cardsPanel.add(card); // Adiciona o card ao painel de cards
    }
    // Adicionando o painel de cards com o JScrollPane
    JScrollPane scrollPane = new JScrollPane(cardsPanel);
    scrollPane.setBounds(20, 120, 550, 200);
    scrollPane.setOpaque(false);
    scrollPane.getViewport().setOpaque(false);

    // Adiciona o JScrollPane ao painel principal
    jPanel3.add(scrollPane);
    jPanel3.revalidate();
    jPanel3.repaint();
    
    jPanel3.add(scrollPane);
    jPanel3.setComponentZOrder(scrollPane, 0); // Garante que os cards fiquem sobre a imagem
}

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        Perfil = new javax.swing.JLabel();
        campoPesquisa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        vender = new javax.swing.JButton();
        Total = new javax.swing.JLabel();
        fundo_de_imagem = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Perfil.setIcon(new javax.swing.ImageIcon("C:\\Users\\devmat\\Documents\\NetBeansProjects\\LojaAutomotiva\\src\\main\\java\\img\\do-utilizador (3).png")); // NOI18N
        Perfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PerfilMouseClicked(evt);
            }
        });

        campoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoPesquisaActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\devmat\\Documents\\NetBeansProjects\\LojaAutomotiva\\src\\main\\java\\img\\lupa.png")); // NOI18N

        vender.setText("Cadastro");
        vender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                venderActionPerformed(evt);
            }
        });

        Total.setIcon(new javax.swing.ImageIcon("C:\\Users\\devmat\\Documents\\NetBeansProjects\\LojaAutomotiva\\src\\main\\java\\img\\carrinho-de-compras-de-design-xadrez.png")); // NOI18N
        Total.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TotalMouseClicked(evt);
            }
        });

        fundo_de_imagem.setIcon(new javax.swing.ImageIcon("C:\\Users\\devmat\\Documents\\NetBeansProjects\\LojaAutomotiva\\src\\main\\java\\img\\car.jpg")); // NOI18N
        fundo_de_imagem.setMaximumSize(new java.awt.Dimension(4000, 4000));
        fundo_de_imagem.setMinimumSize(new java.awt.Dimension(4000, 4000));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(Perfil, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(campoPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(vender))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(540, 540, 540)
                .addComponent(Total))
            .addComponent(fundo_de_imagem, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Perfil, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(220, 220, 220)
                .addComponent(vender))
            .addComponent(fundo_de_imagem, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(320, 320, 320)
                .addComponent(Total))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoPesquisaActionPerformed

    private void venderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_venderActionPerformed
        // TODO add your handling code here:
         TelaCadastro cadastro = new TelaCadastro();
        cadastro.setVisible(true);
        dispose();
    }//GEN-LAST:event_venderActionPerformed

    private void PerfilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PerfilMouseClicked
        JOptionPane.showMessageDialog(null,"Está vindo na proxima atualização!");


    }//GEN-LAST:event_PerfilMouseClicked

    private void TotalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TotalMouseClicked
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null,"Está vindo na proxima atualização!");

    }//GEN-LAST:event_TotalMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run(){ 
                new TelaCompra().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Perfil;
    private javax.swing.JLabel Total;
    private javax.swing.JTextField campoPesquisa;
    private javax.swing.JLabel fundo_de_imagem;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton vender;
    // End of variables declaration//GEN-END:variables
}
