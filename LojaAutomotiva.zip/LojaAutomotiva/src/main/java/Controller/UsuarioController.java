/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ConexaoBancoDeDados;

/**
 *
 * @author jhessikkaelly
 */
public class UsuarioController {
    
    // criando metodo de inserir usuario no banco de dados
    
    public boolean cadastrandoUsuario(Usuario user){
        // comando do banco de dados para inserir
        String query = 
         "INSERT INTO Usuario(nome,cpf,senha,email,data_nascimento)"
                + "VALUES(?,?,?,?,?);";
        
        // Connection - conecta-se ao banco de dados
        // PreparedStatement manda o comando sql para executar no BD
        try(Connection conection = ConexaoBancoDeDados.getConnection();
        PreparedStatement preparedStatement =
                conection.prepareStatement(query)){       
            
            // mandar os dados para dentro do insert
            preparedStatement.setString(1,user.getNome());
            preparedStatement.setString(2, user.getCpf());
            preparedStatement.setString(3,user.getSenha());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setDate(5, user.getDataNascimento());
            
            /*try(ResultSet resultSet = preparedStatement.executeQuery()){
                return resultSet.next();
            }// final do segundo try*/
            // verifica se o insert foi executado
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
            
        }catch(SQLException e){
            // imprimindo erro que deu ao inserir usuário
            System.err.print("Erro ao Inserir Dados!" + e);
            return false;
        }// final do try catch
        
    }// fim do metodo cadastrandoUsuario()
    public boolean deletaUsuario(int idusuario){
          String query = "DELETE FROM Usuario WHERE id_cliente= ?;";
        
         try (Connection connection = ConexaoBancoDeDados.getConnection();// conexão com banco de dados
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {// mandar o comando select para ser executado no BD
            
            // madando o idusuario para dentro do comando sql
            preparedStatement.setInt(1,idusuario);
             int rowsffected = preparedStatement.executeUpdate();
              return rowsffected > 0;
                           
    }catch(SQLException e){
        System.err.print("Exclusão não realizada!"+ e);
        return false;
        
    }// final do catch
    }// fim do metodo deletar
    
  
    
     public boolean ATUALIZARUsuario(Usuario user){
        // comando do banco de dados para inserir
        String query = 
         "UPDATE Usuario SET nome = ?,cpf = ?,senha= ?,email= ?,data_nascimento= ?";
        // Connection - conecta-se ao banco de dados
        // PreparedStatement manda o comando sql para executar no BD
        try(Connection conection = ConexaoBancoDeDados.getConnection();
        PreparedStatement preparedStatement =
                conection.prepareStatement(query)){       
            
            // mandar os dados para dentro do insert
            preparedStatement.setString(1,user.getNome());
            preparedStatement.setString(2, user.getCpf());
            preparedStatement.setString(3,user.getSenha());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setDate(5, user.getDataNascimento());
            
            /*try(ResultSet resultSet = preparedStatement.executeQuery()){
                return resultSet.next();
            }// final do segundo try*/
            // verifica se o insert foi executado
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
            
        }catch(SQLException e){
            // imprimindo erro que deu ao inserir usuário
            System.err.print("Erro ao atualizar Dados de usuario!" + e);
            return false;
        }// final do try catch

    }// fim do metodo cadastrandoUsuario()
}  