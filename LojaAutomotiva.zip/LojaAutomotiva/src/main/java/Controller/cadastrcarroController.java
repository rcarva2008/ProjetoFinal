package Controller;

import model.ConexaoBancoDeDados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Carros;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class cadastrcarroController {
    
    public boolean cadastrandoCarros(Carros carro) {
        String query = "INSERT INTO Carros (Preco, Modelo, Cor, Placa, descricao, VendaAlugar, Imagem) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = ConexaoBancoDeDados.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, carro.getPreco());
            preparedStatement.setString(2, carro.getModelo());
            preparedStatement.setString(3, carro.getCor());
            preparedStatement.setString(4, carro.getPlaca());
            preparedStatement.setString(5, carro.getDescricao());
            preparedStatement.setString(6, carro.getVendaAlugar());

            // Salvar a imagem como bytes, se existir
            if (carro.getImagem() != null) {
                preparedStatement.setBytes(7, carro.getImagem()); // Imagem como bytes
            } else {
                preparedStatement.setNull(7, java.sql.Types.BLOB); // Caso a imagem seja nula
            }

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Retorna true se alguma linha foi afetada

        } catch (SQLException e) {
            System.err.println("Erro ao inserir carro no banco de dados: " + e.getMessage());
            return false;
        }
    }
    
     public byte[] convertImageToBytes(String imagePath) throws IOException {
        File imageFile = new File(imagePath);
        try (FileInputStream fis = new FileInputStream(imageFile);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            return baos.toByteArray();
        }
    }

    /* public boolean cadastrandoCarros(Carros carro) {
        // Comando SQL para inserir os dados no banco de dados, incluindo a imagem
        String query = "INSERT INTO Carros (Preco, Modelo, Cor, Placa, descricao, VendaAlugar, Imagem) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = ConexaoBancoDeDados.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Atribuindo os valores aos parâmetros do SQL
            preparedStatement.setString(1, carro.getPreco());
            preparedStatement.setString(2, carro.getModelo());
            preparedStatement.setString(3, carro.getCor());
            preparedStatement.setString(4, carro.getPlaca());
            preparedStatement.setString(5, carro.getDescricao());
            preparedStatement.setString(6, carro.getVendaAlugar());
            
            // Convertendo a imagem em um array de bytes (se houver)
            if (carro.getImagem() != null) {
                byte[] imagemBytes = convertImageToBytes(carro.getImagem());
                preparedStatement.setBytes(7, imagemBytes); // Imagem como bytes
            } else {
                preparedStatement.setNull(7, java.sql.Types.BLOB); // Caso a imagem seja nula
            }

            // Executar a inserção e verificar se foi bem-sucedida
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Retorna true se alguma linha foi afetada

        } catch (SQLException e) {
            System.err.println("Erro ao inserir carro no banco de dados: " + e.getMessage());
            return false;
        } catch (IOException e) {
            System.err.println("Erro ao converter imagem: " + e.getMessage());
            return false;
        }
    }

    // Função para converter a imagem em bytes
   
    public List<Carros> listarCarros(){
        String query = "SELECT * FROM Carros;";
        // criando uma lista para capturar os dados do select
        List<Carros> lista = new ArrayList<>();
        // criando o try catch
        try(Connection conection = ConexaoBancoDeDados.getConnection();
        PreparedStatement preparedStatement =conection.prepareStatement(query);
         ResultSet resultset = preparedStatement.executeQuery() ){
            
            // passando o valor do select para um objeto produto
            // enquanto resultset for diferente de null
            while(resultset.next()){
                // receba o valor e cadastre em produto
                  Carros carro = new Carros();
                  carro.setId(resultset.getInt("id"));
                  carro.setPreco(resultset.getString("preco"));
                  carro.setModelo(resultset.getString("modelo"));
                  carro.setCor(resultset.getString("cor"));
                  carro.setPlaca(resultset.getString("placa"));
                  carro.setDescricao(resultset.getString("descricao"));
                  carro.setVendaAlugar(resultset.getString("vendaAlugar"));
                  carro.setImagem(resultset.getString("imagem"));
                  // jogando o produto dentro da lista
                  lista.add(carro);
             }// fim do while
            return lista;
           
        }catch(SQLException e){
            System.err.print("Erro ao listar carros "+e);
            return null;
        }// final do try catch
    }// fim do metodo listarProdutos()
*/
    
    public List<Carros> listarCarros() {
    String query = "SELECT * FROM Carros ORDER BY NEWID();";
    List<Carros> lista = new ArrayList<>();
    try (Connection connection = ConexaoBancoDeDados.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(query);
         ResultSet resultSet = preparedStatement.executeQuery()) {

        while (resultSet.next()) {
            Carros carro = new Carros();
            carro.setId(resultSet.getInt("id"));
            carro.setPreco(resultSet.getString("preco"));
            carro.setModelo(resultSet.getString("modelo"));
            carro.setCor(resultSet.getString("cor"));
            carro.setPlaca(resultSet.getString("placa"));
            carro.setDescricao(resultSet.getString("descricao"));
            carro.setVendaAlugar(resultSet.getString("vendaAlugar"));

            // Lendo a imagem como array de bytes
            byte[] imagemBytes = resultSet.getBytes("imagem");
            if (imagemBytes != null) {
                carro.setImagem(imagemBytes); // Atualiza o campo de imagem
            }

            lista.add(carro);
        }
        return lista;

    } catch (SQLException e) {
        System.err.print("Erro ao listar carros: " + e);
        return null;
    }
}

    public List<Carros> listarCarrosModelo(String modelo) {
    String query = "SELECT * FROM Carros Where modelo LIKE ?;";
    List<Carros> lista = new ArrayList<>();
    try (Connection connection = ConexaoBancoDeDados.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(query)
         ) {
        
        preparedStatement.setString(1, '%'+modelo+'%');
        
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            Carros carro = new Carros();
            carro.setId(resultSet.getInt("id"));
            carro.setPreco(resultSet.getString("preco"));
            carro.setModelo(resultSet.getString("modelo"));
            carro.setCor(resultSet.getString("cor"));
            carro.setPlaca(resultSet.getString("placa"));
            carro.setDescricao(resultSet.getString("descricao"));
            carro.setVendaAlugar(resultSet.getString("vendaAlugar"));

            // Lendo a imagem como array de bytes
            byte[] imagemBytes = resultSet.getBytes("imagem");
            if (imagemBytes != null) {
                carro.setImagem(imagemBytes); // Atualiza o campo de imagem
            }

            lista.add(carro);
        }
        return lista;

    } catch (SQLException e) {
        System.err.print("Erro ao listar carros: " + e);
        return null;
    }
}

    
    
}
